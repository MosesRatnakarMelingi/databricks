# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC There are quite a few properties related to Adaptive execution. We can go to official documentation of Spark and review the details related to adaptive execution.

# COMMAND ----------

